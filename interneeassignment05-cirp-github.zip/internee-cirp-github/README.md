# Cyber Incident Response Plan (CIRP) – Internee.pk

This repository contains my Cyber Security assignment:
- A simulated ransomware attack response
- Detection, containment, eradication, and recovery steps
- Incident report (DOCX/PDF)
- Technical artifacts bundle (.tgz)

## Contents
- `incident_report.docx` → Formal incident response report
- `CIRP_InterneePK_<timestamp>.tgz` → Artifacts, logs, backups, and simulation files
- `README.md` → Project overview

## How to Use
1. Extract the `.tgz` file:
   ```bash
   tar -xzf CIRP_InterneePK_<timestamp>.tgz
